<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_only_cookies', 1);

session_start();
include 'db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

if (isset($_GET['logout'])) {
    session_destroy();
    echo "<script>alert('Logout Successfully'); window.location='login.php';</script>";
    exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['csrf_token'])) {
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('Invalid CSRF token');
    }
}

$results = null;
if (isset($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
    $query = "SELECT patient_id AS id, CONCAT(first_name, ' ', last_name) AS name FROM patient WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%' 
              UNION SELECT doctor_id AS id, CONCAT(first_name, ' ', last_name) AS name FROM doctor WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%' 
              UNION SELECT department_id AS id, department_name AS name FROM department WHERE department_name LIKE '%$search%'";
    $results = $conn->query($query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body { font-family: Arial, sans-serif; background: url('img/Background.jpg') no-repeat center center fixed; background-size: cover; margin: 0; padding: 0; }
    .dashboard-container { width: 80%; margin: auto; padding: 20px; }
    h1 { text-align: center; color: #007BFF; font-size: 32px; }
    .card { background: white; padding: 20px; margin: 20px 0; box-shadow: 0px 4px 10px rgba(0,0,0,0.2); border-radius: 15px; transition: transform 0.3s; }
    .card:hover { transform: scale(1.03); }
    .card h2 { color: #007BFF; font-size: 24px; }
    .btn { display: inline-block; padding: 12px 25px; background-color: #007BFF; color: white; text-decoration: none; border-radius: 5px; font-size: 18px; transition: 0.3s; }
    .btn:hover { background-color: #0056b3; transform: scale(1.05); }
    .search-container { text-align: center; margin: 20px 0; }
    input[type="text"] { padding: 10px; width: 60%; border: 1px solid #007BFF; border-radius: 5px; }
    .search-btn { padding: 10px 20px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; transition: 0.3s; }
    .search-btn:hover { background-color: #0056b3; }
    .stats { display: flex; justify-content: space-around; flex-wrap: wrap; }
    .stat-box { background: #007BFF; color: white; padding: 20px; border-radius: 10px; text-align: center; width: 30%; margin: 10px 0; }
  </style>
</head>
<body>
  <div class="dashboard-container">
    <h1>Admin Dashboard</h1>

    <div class="search-container">
      <form action="" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <input type="text" name="search" placeholder="Search Patients, Doctors, Departments...">
        <button type="submit" class="search-btn">Search</button>
      </form>
    </div>

    <?php if ($results && $results->num_rows > 0): ?>
    <div class="card">
      <h2>Search Results</h2>
      <ul>
        <?php while ($row = $results->fetch_assoc()): ?>
          <li><?php echo htmlspecialchars($row['name']); ?></li>
        <?php endwhile; ?>
      </ul>
    </div>
    <?php elseif ($results): ?>
    <div class="card"><p>No results found.</p></div>
    <?php endif; ?>

    <div class="stats">
      <div class="stat-box">Total Patients: <?php echo $conn->query("SELECT COUNT(*) FROM patient")->fetch_row()[0]; ?></div>
      <div class="stat-box">Total Doctors: <?php echo $conn->query("SELECT COUNT(*) FROM doctor")->fetch_row()[0]; ?></div>
      <div class="stat-box">Total Appointments: <?php echo $conn->query("SELECT COUNT(*) FROM appointment")->fetch_row()[0]; ?></div>
    </div>

    <div class="card">
      <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user']['employer_name'] ?? 'Admin'); ?>!</h2>
      <p>Manage hospital departments, doctors, patients, appointments, records, and payments here.</p>
      <a href="?logout" class="btn">Logout</a>
    </div>

    <div class="card">
      <h2>Quick Links</h2>
      <a href="department.php" class="btn">Departments</a>
      <a href="doctor.php" class="btn">Doctors</a>
      <a href="patient.php" class="btn">Patients</a>
      <a href="appointment.php" class="btn">Appointments</a>
      <a href="medicalrecords.php" class="btn">Medical Records</a>
      <a href="payment.php" class="btn">Payments</a>
    </div>
  </div>
</body>
</html>
