# Care-Compass-Hospitals
A user-friendly, database-driven platform for hospital management system.
