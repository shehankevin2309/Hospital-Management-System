<?php
include 'db.php';

// Function to create a new doctor record
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['doctor-name'];
    $specialty = $_POST['specialty'];
    $qualifications = $_POST['qualifications'];
    $email = $_POST['contact-email'];
    $phone = $_POST['phone-number'];
    $gender = $_POST['gender'];
    $medical_history = $_POST['medical-history'];

    $stmt = $conn->prepare("INSERT INTO Doctor (first_name, specialty, phone, email, gender, qualifications, medical_history) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $specialty, $phone, $email, $gender, $qualifications, $medical_history);

    if ($stmt->execute()) {
        echo "<script>alert('Doctor registered successfully!'); window.location.href='doctor.php';</script>";
    } else {
        echo "<script>alert('Error: ' . $stmt->error); window.location.href='doctor.php';</script>";
    }

    $stmt->close();
}

// Function to get all doctors
function getDoctors() {
    global $conn;
    $result = $conn->query("SELECT * FROM Doctor ORDER BY doctor_id DESC");
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Fetch doctors
$doctors = getDoctors();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Doctors</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('img/Background.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
            text-align: center;
            color: white;
        }
        .container {
            width: 80%;
            margin: auto;
            background: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 10px;
            margin-top: 50px;
            box-shadow: 0px 0px 15px rgba(255, 255, 255, 0.2);
        }
        h1 {
            color: rgb(191, 201, 221);
            text-shadow: 2px 2px 10px rgba(255, 255, 255, 0.5);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: rgba(255, 255, 255, 0.1);
        }
        th, td {
            padding: 12px;
            border: 2px solid #FFD700;
            color: white;
        }
        th {
            background-color: rgba(0, 0, 0, 0.8);
        }
        tr:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
        .btn {
            padding: 8px 12px;
            background-color: #FFD700;
            color: black;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #FFA500;
        }
        .back-btn {
            display: block;
            margin-top: 15px;
            color: #FFD700;
            text-decoration: none;
        }
        .back-btn:hover {
            color: #FFA500;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            border-radius: 5px;
            border: 1px solid #FFD700;
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Doctor Records</h1>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Specialty</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($doctors as $doctor) : ?>
                <tr>
                    <td><?= $doctor['doctor_id'] ?></td>
                    <td><?= $doctor['first_name'] ?></td>
                    <td><?= $doctor['specialty'] ?></td>
                    <td><?= $doctor['email'] ?></td>
                    <td><?= $doctor['phone'] ?></td>
                    <td>
                        <a href="edit_doctor.php?id=<?= $doctor['doctor_id'] ?>" class="btn">Edit</a>
                        <a href="delete_doctor.php?id=<?= $doctor['doctor_id'] ?>" onclick="return confirm('Are you sure?')" class="btn">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>

    <div class="container">
        <h2>Register a New Doctor</h2>
        <form action="doctor.php" method="POST">
            <label>Name:</label>
            <input type="text" name="doctor-name" placeholder="Doctor's Name" required>
            <label>Specialty:</label>
            <input type="text" name="specialty" placeholder="Specialty" required>
            <label>Qualifications:</label>
            <input type="text" name="qualifications" placeholder="Qualifications" required>
            <label>Email:</label>
            <input type="email" name="contact-email" placeholder="Email" required>
            <label>Phone Number:</label>
            <input type="tel" name="phone-number" placeholder="Phone Number" required>
            <label>Gender:</label>
            <select name="gender" required>
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>
            <label>Medical History:</label>
            <textarea name="medical-history" placeholder="Medical History"></textarea>
            <button type="submit" class="btn">Register Doctor</button>
        </form>
        <a href="dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
    </div>

</body>
</html>
