<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Care Compass - Services</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f8fb;
      margin: 0;
      padding: 0;
    }
    .container {
      width: 60%;
      margin: auto;
      background: white;
      padding: 20px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      margin-top: 20px;
    }
    h1, h2 {
      text-align: center;
      color: #007BFF;
    }
    label {
      font-weight: bold;
      margin-top: 10px;
      display: block;
    }
    select, textarea {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #007BFF;
      border-radius: 5px;
      background-color: white;
    }
    .btn {
      display: block;
      width: 100%;
      padding: 12px;
      background-color: #28a745;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      text-align: center;
      margin-top: 15px;
    }
    .btn:hover {
      background-color: #218838;
    }
    .back-btn {
      display: block;
      text-align: center;
      margin-top: 10px;
      font-size: 14px;
    }
  </style>
  <script>
    function redirectService(event) {
      event.preventDefault(); // Prevent form submission

      let service = document.getElementById("services").value;
      
      if (service === "lab_results") {
        window.location.href = "labresults.php";
      } else if (service === "bill_payment") {
        window.location.href = "payment.php";
      } else {
        alert("Please select a service before submitting.");
      }
    }
  </script>
</head>
<body>

  <header class="services-header">
    <div class="container">
      <h1>Our Services</h1>
    </div>
  </header>

  <section class="services-content">
    <div class="container">
      <a href="index.php" class="back-btn">⬅ Go Back to Home</a>
    </div>
  </section>

  <!-- Services Form -->
  <section class="services-form">
    <div class="container">
      <h2>Select a Service</h2>
      <form onsubmit="redirectService(event)">
        <label for="services">Choose a Service:</label>
        <select id="services" name="services" required>
          <option value="">-- Select Service --</option>
          <option value="lab_results">Lab Results</option>
          <option value="bill_payment">Bill Payment</option>
        </select>

        <label for="description">Additional Information (Optional):</label>
        <textarea id="description" name="description" rows="4" placeholder="Provide any relevant details..."></textarea>

        <button type="submit" class="btn">Submit Request</button>
      </form>
    </div>
  </section>

</body>
</html>
