<?php
session_start();
if (isset($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Registration</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: url('img/Background.jpg') no-repeat center center fixed;
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .container {
      background: rgba(255, 255, 255, 0.9);
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      text-align: center;
      width: 100%;
      max-width: 400px;
    }
    h1 {
      color: #007BFF;
    }
    label {
      display: block;
      font-weight: bold;
      margin-top: 10px;
      text-align: left;
    }
    input {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border-radius: 5px;
      border: 1px solid #007BFF;
    }
    button {
      width: 100%;
      padding: 10px;
      margin-top: 15px;
      background-color: #007BFF;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
    }
    button:hover {
      background-color: #0056b3;
    }
    p {
      margin-top: 15px;
    }
    a {
      color: #007BFF;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Admin Registration</h1>
    <form action="auth.php" method="POST">
      <label>Employer Name:</label>
      <input type="text" name="employer_name" required>
      <label>Employer ID:</label>
      <input type="text" name="employer_id" required>
      <label>Password:</label>
      <input type="password" name="password" required>
      <label>Mobile Number:</label>
      <input type="tel" name="mobile_number" required>
      <label>Home Address:</label>
      <input type="text" name="home_address" required>
      <button type="submit" name="register">Register</button>
      <p>Already have an account? <a href="login.php">Login here</a></p>
    </form>
  </div>
</body>
</html>