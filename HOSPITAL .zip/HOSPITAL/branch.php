<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Our Branches</title>
  <link rel="stylesheet" href="style.css">
  <style>

    .branches-header {
      background: url('img/banner2.webp') no-repeat center/cover;
      height: 300px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      color: white;
      position: relative;
    }
    
    .branches-header::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
    }

    .branches-header h1,
    .branches-header p {
      position: relative;
      z-index: 1;
    }

    .branches-section {
      padding: 50px 20px;
      text-align: center;
    }

    .branches-grid {
      display: flex;
      justify-content: center;
      gap: 20px;
      flex-wrap: wrap;
    }

    .branch-card {
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      text-align: center;
      width: 300px;
    }

    .branch-card img {
      width: 100%;
      border-radius: 10px;
      height: 200px;
      object-fit: cover;
    }

    .btn {
      display: inline-block;
      padding: 12px 20px;
      background-color: #007BFF;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-size: 18px;
      transition: 0.3s;
    }

    .btn:hover {
      background-color: #0056b3;
    }

    
    footer {
      text-align: center;
      padding: 20px;
      margin-top: 20px;
    }

  </style>
</head>
<body>

  
  <header class="branches-header">
    <h1>Our Branches</h1>
    <p>Conveniently located in key cities to provide you with the best healthcare services.</p>
  </header>

  <!-- Branches Section -->
  <section class="branches-section">
    <div class="container">
      <h2>Explore Our Locations</h2>
      <div class="branches-grid">
        <!-- Branch 1 -->
        <div class="branch-card">
          <img src="img/hos1.jpg" alt="Kandy Branch">
          <h3>Kandy</h3>
          <p>No. 12, Peradeniya Road, Kandy</p>
          <p><strong>Contact:</strong> +94 81 123 4567</p>
        </div>
        <!-- Branch 2 -->
        <div class="branch-card">
          <img src="img/hos2.webp" alt="Colombo Branch">
          <h3>Colombo</h3>
          <p>No. 45, Galle Road, Colombo 03</p>
          <p><strong>Contact:</strong> +94 11 234 5678</p>
        </div>
        <!-- Branch 3 -->
        <div class="branch-card">
          <img src="img/hos3.webp" alt="Kurunegala Branch">
          <h3>Kurunegala</h3>
          <p>No. 88, Negombo Road, Kurunegala</p>
          <p><strong>Contact:</strong> +94 37 345 6789</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Back to Home Button -->
  <footer>
    <a href="index.php" class="btn">Back to Home</a>
  </footer>

</body>
</html>
