<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch first_name and last_name directly from the form
    $first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : '';
    $last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : '';
    $dob = isset($_POST['dob']) ? $_POST['dob'] : '';
    $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
    $address = isset($_POST['address']) ? trim($_POST['address']) : '';

    // Prepare the SQL statement with correct column names
    $stmt = $conn->prepare("INSERT INTO patient (first_name, last_name, dob, gender, email, phone, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $first_name, $last_name, $dob, $gender, $email, $phone, $address);

    if ($stmt->execute()) {
        echo "<script>alert('Patient registered successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); window.location.href='submit_patient_registration.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Patient Registration</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body { font-family: Arial, sans-serif; background-color: #f4f8fb; margin: 0; padding: 0; }
    .container { width: 50%; margin: auto; background: white; padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; margin-top: 20px; }
    h1 { text-align: center; color: #007BFF; }
    form { margin-top: 20px; }
    label { font-weight: bold; display: block; margin-top: 10px; }
    input, select { width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #007BFF; border-radius: 5px; }
    .btn { width: 100%; padding: 12px; background-color: #28a745; color: white; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; margin-top: 15px; }
    .btn:hover { background-color: #218838; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Patient Registration</h1>
    <form action="submit_patient_registration.php" method="POST">
      <label>Full Name:</label>
      <input type="text" name="patient-name" required>
      <label>Date of Birth:</label>
      <input type="date" name="dob" required>
      <label>Gender:</label>
      <select name="gender" required>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        <option value="Other">Other</option>
      </select>
      <label>Email:</label>
      <input type="email" name="email" required>
      <label>Phone:</label>
      <input type="tel" name="phone" required>
      <button type="submit" class="btn">Register Patient</button>
    </form>
  </div>
</body>
</html>
