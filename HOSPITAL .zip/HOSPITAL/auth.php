<?php
session_start();
include 'db.php';

if (isset($_POST['register'])) {
    $employer_name = $_POST['employer_name'];
    $employer_id = $_POST['employer_id'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $mobile_number = $_POST['mobile_number'];
    $home_address = $_POST['home_address'];

    $query = "INSERT INTO login (employer_name, employer_id, password, mobile_number, home_address) 
              VALUES ('$employer_name', '$employer_id', '$password', '$mobile_number', '$home_address')";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Registration successful! Please log in.'); window.location='login.php';</script>";
    } else {
        echo "<script>alert('Registration failed! Try again.'); window.location='register.php';</script>";
    }
}

if (isset($_POST['login'])) {
    $employer_id = $_POST['employer_id'];
    $password = $_POST['password'];

    $query = "SELECT * FROM login WHERE employer_id = '$employer_id'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;
            header('Location: dashboard.php');
            exit();
        } else {
            echo "<script>alert('Incorrect password!'); window.location='login.php';</script>";
        }
    } else {
        echo "<script>alert('Employer ID not found!'); window.location='login.php';</script>";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}
?>
