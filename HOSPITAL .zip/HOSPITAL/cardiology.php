<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cardiology Appointments</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="appointment-header">
    <div class="container">
      <h1>Cardiology Appointment</h1>
      <p>Schedule your appointment with our cardiology specialists.</p>
    </div>
  </header>

  <section class="appointment-form-section">
    <div class="container">
      <form action="submit-appointment.php" method="POST" class="appointment-form">
        <label for="name">Full Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email Address:</label>
        <input type="email" id="email" name="email" required>

        <label for="phone">Phone Number:</label>
        <input type="tel" id="phone" name="phone" required>

        <label for="date">Preferred Appointment Date:</label>
        <input type="date" id="date" name="date" required>

        <label for="time">Preferred Time:</label>
        <input type="time" id="time" name="time" required>

        <label for="message">Additional Information:</label>
        <textarea id="message" name="message" rows="4"></textarea>

        <button type="submit" class="btn submit-btn">Book Appointment</button>
      </form>

      <a href="departments.php" class="btn back-btn">Back to Departments</a>
    </div>
  </section>
</body>
</html>
