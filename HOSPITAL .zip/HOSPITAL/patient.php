<?php
include 'db.php';

// Function to get all patients
function getPatients() {
    global $conn;
    $result = $conn->query("SELECT * FROM Patient ORDER BY patient_id DESC");
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to delete a patient
function deletePatient($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM Patient WHERE patient_id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Handling form deletion
if (isset($_GET['delete_id'])) {
    deletePatient($_GET['delete_id']);
    header("Location: patient.php");
    exit();
}

$patients = getPatients();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Patients</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('img/hos1.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 80%;
            margin: auto;
            background: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 10px;
        }
        h1 {
            color: #FFD700;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: rgba(255, 255, 255, 0.1);
        }
        th, td {
            padding: 12px;
            border: 2px solid #FFD700;
            color: white;
        }
        th {
            background-color: rgba(0, 0, 0, 0.8);
        }
        tr:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
        .btn {
            padding: 8px 12px;
            background-color: #FFD700;
            color: black;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #FFA500;
        }
        .back-btn {
            display: block;
            margin-top: 15px;
            color: #FFD700;
            text-decoration: none;
        }
        .back-btn:hover {
            color: #FFA500;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Patient Records</h1>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>DOB</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($patients as $patient) : ?>
                <tr>
                    <td><?= $patient['patient_id'] ?></td>
                    <td><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></td>
                    <td><?= $patient['dob'] ?></td>
                    <td><?= $patient['gender'] ?></td>
                    <td><?= $patient['email'] ?></td>
                    <td><?= $patient['phone'] ?></td>
                    <td>
                        <a href="edit_patient.php?id=<?= $patient['patient_id'] ?>" class="btn">Edit</a>
                        <a href="patient.php?delete_id=<?= $patient['patient_id'] ?>" onclick="return confirm('Are you sure?')" class="btn">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <a href="dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
    </div>

</body>
</html>
