<?php
// delete_doctor.php
include 'db.php';
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conn->query("DELETE FROM Doctor WHERE doctor_id=$id");
    echo "<script>alert('Doctor deleted successfully!'); window.location.href='doctor.php';</script>";
}
?>