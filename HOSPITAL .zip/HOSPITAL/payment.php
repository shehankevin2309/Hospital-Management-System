<?php
include 'db.php';

// CRUD operations for Payments
function createPayment($patient_id, $amount, $date, $method) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO Payment (patient_id, amount, payment_date, payment_method) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("idss", $patient_id, $amount, $date, $method);
    $stmt->execute();
    $stmt->close();
}

function getPayments() {
    global $conn;
    $result = $conn->query("SELECT * FROM Payment");
    return $result->fetch_all(MYSQLI_ASSOC);
}

function updatePayment($id, $patient_id, $amount, $date, $method) {
    global $conn;
    $stmt = $conn->prepare("UPDATE Payment SET patient_id=?, amount=?, payment_date=?, payment_method=? WHERE payment_id=?");
    $stmt->bind_param("idssi", $patient_id, $amount, $date, $method, $id);
    $stmt->execute();
    $stmt->close();
}

function deletePayment($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM Payment WHERE payment_id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payments</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body { font-family: Arial, sans-serif; background-color: #f4f8fb; margin: 0; padding: 0; }
    .container { width: 60%; margin: auto; background: white; padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; margin-top: 20px; }
    h1, h2 { text-align: center; color: #007BFF; }
    table { width: 100%; margin-top: 20px; border-collapse: collapse; }
    th, td { padding: 12px; border: 1px solid #007BFF; text-align: left; }
    th { background-color: #007BFF; color: white; }
    input, select, button { width: 100%; padding: 10px; margin-top: 10px; border: 1px solid #007BFF; border-radius: 5px; }
    .btn { background-color: #28a745; color: white; border: none; cursor: pointer; }
    .btn:hover { background-color: #218838; }
    
    /* Back to Home button styles */
    .home-btn {
      display: block;
      width: 100%;
      padding: 12px;
      background-color: #007BFF;
      color: white;
      text-align: center;
      font-size: 16px;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      margin-top: 15px;
      transition: background 0.3s ease-in-out;
    }
    .home-btn:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Manage Payments</h1>
    <form action="payment.php" method="POST">
      <label>Patient ID:</label>
      <input type="text" name="patient_id" required>
      <label>Amount:</label>
      <input type="number" step="0.01" name="amount" required>
      <label>Payment Date:</label>
      <input type="date" name="date" required>
      <label>Payment Method:</label>
      <select name="method" required>
        <option value="Credit Card">Credit Card</option>
        <option value="Cash">Cash</option>
        <option value="Bank Transfer">Bank Transfer</option>
      </select>
      <button type="submit" class="btn">Add Payment</button>
    </form>

    <!-- Back to Home Button -->
    <a href="index.php" class="home-btn">⬅ Back to Home</a>

    <h2>Payment Records</h2>
    <table>
      <tr>
        <th>ID</th>
        <th>Patient ID</th>
        <th>Amount</th>
        <th>Date</th>
        <th>Method</th>
        <th>Actions</th>
      </tr>
      <?php
      $payments = getPayments();
      foreach ($payments as $payment) {
          echo "<tr>
                  <td>{$payment['payment_id']}</td>
                  <td>{$payment['patient_id']}</td>
                  <td>\${$payment['amount']}</td>
                  <td>{$payment['payment_date']}</td>
                  <td>{$payment['payment_method']}</td>
                  <td><a href='edit_payment.php?id={$payment['payment_id']}'>Edit</a> | <a href='delete_payment.php?id={$payment['payment_id']}'>Delete</a></td>
                </tr>";
      }
      ?>
    </table>
  </div>
</body>
</html>
