<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Emergency Cases</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      margin: 0;
      padding: 0;
    }
    .container {
      width: 60%;
      margin: auto;
      background: white;
      padding: 20px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      margin-top: 20px;
    }
    h1, h2, h3 {
      text-align: center;
      color: #dc3545;
    }
    p {
      text-align: center;
      font-size: 16px;
    }
    ul {
      list-style: none;
      padding: 0;
      text-align: center;
    }
    ul li {
      background: #dc3545;
      color: white;
      display: inline-block;
      padding: 10px 20px;
      margin: 5px;
      border-radius: 5px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 12px;
      border: 2px solid #dc3545;
    }
    th {
      background-color: #dc3545;
      color: white;
      text-align: left;
    }
    td input, td select, td textarea {
      width: 95%;
      padding: 8px;
      border: 1px solid #dc3545;
      border-radius: 5px;
    }
    td textarea {
      resize: none;
    }
    .btn {
      display: block;
      width: 100%;
      padding: 12px;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      text-align: center;
      margin-top: 10px;
    }
    .register-btn {
      background-color: #28a745;
    }
    .register-btn:hover {
      background-color: #218838;
    }
    .delete-btn {
      background-color: #dc3545;
    }
    .delete-btn:hover {
      background-color: #c82333;
    }
    .back-btn {
      display: block;
      text-align: center;
      margin-top: 10px;
      font-size: 14px;
    }
  </style>
</head>
<body>

  <header class="emergency-header">
    <div class="container">
      <h1>Emergency Cases</h1>
    </div>
  </header>

  <section class="emergency-content">
    <div class="container">
      <h2>Emergency Care Services</h2>
      
      <h3>Our Emergency Services Include:</h3>
      <ul>
        <li>24/7 Ambulance Services</li>
        <li>Trauma and Accident Care</li>
        <li>Cardiac and Stroke Emergency</li>
        <li>Pediatric Emergency</li>
        <li>On-site Critical Care Units</li>
      </ul>
      <p><strong>Contact Emergency Care:</strong> Dial <a href="tel:+94112345678">+94 11 234 5678</a></p>
      <a href="index.php" class="btn back-btn">Go Back to Home</a>
    </div>
  </section>

  <!-- Emergency Registration Form -->
  <section class="registration-form">
    <div class="container">
      <h2>Emergency Patient Registration</h2>
      <form action="submit_form.php" method="POST">
        <table>
          <tr>
            <th>Field</th>
            <th>Input</th>
          </tr>
          <tr>
            <td><label for="full-name">Full Name:</label></td>
            <td><input type="text" id="full-name" name="full-name" required></td>
          </tr>
          <tr>
            <td><label for="email">Email:</label></td>
            <td><input type="email" id="email" name="email" required></td>
          </tr>
          <tr>
            <td><label for="phone">Phone Number:</label></td>
            <td><input type="tel" id="phone" name="phone" required></td>
          </tr>
          <tr>
            <td><label for="dob">Date of Birth:</label></td>
            <td><input type="date" id="dob" name="dob" required></td>
          </tr>
          <tr>
            <td><label for="gender">Gender:</label></td>
            <td>
              <select id="gender" name="gender" required>
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </td>
          </tr>
          <tr>
            <td><label for="medical-history">Medical History:</label></td>
            <td><textarea id="medical-history" name="medical-history" rows="4" placeholder="Provide any relevant medical history..."></textarea></td>
          </tr>
          <tr>
            <td><label for="emergency-type">Emergency Type:</label></td>
            <td>
              <select id="emergency-type" name="emergency-type" required>
                <option value="">Select Emergency Type</option>
                <option value="trauma">Trauma</option>
                <option value="cardiac">Cardiac</option>
                <option value="stroke">Stroke</option>
                <option value="pediatric">Pediatric</option>
                <option value="other">Other</option>
              </select>
            </td>
          </tr>
        </table>

        <button type="submit" class="btn register-btn">Register</button>
        <button type="reset" class="btn delete-btn">Delete</button>
      </form>
    </div>
  </section>

</body>
</html>
