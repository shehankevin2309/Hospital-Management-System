<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Departments</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(3, 2, 2, 0.85);
      justify-content: center;
      align-items: center;
      text-decoration: none;
    }

    .modal-content {
      background: #fff;
      padding: 20px;
      border-radius: 5px;
      max-width: 400px;
      width: 100%;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .modal-header h3 {
      margin: 0;
    }

    .modal-close {
      cursor: pointer;
      font-size: 20px;
    }

    .departments-header {
      background: url('img/banner3.jpg') no-repeat center center;
      background-size: cover;
      text-align: center;
      padding: 100px 20px;
      color: white;
    }

    .register-btn {
      display: inline-block;
      padding: 12px 20px;
      background: linear-gradient(45deg, #007bff, #00c6ff);
      color: white;
      text-decoration: none;
      font-weight: bold;
      border-radius: 25px;
      transition: 0.3s ease-in-out;
      text-align: center;
    }

    .register-btn:hover {
      background: linear-gradient(45deg, #0056b3, #0096ff);
      transform: scale(1.1);
    }

    .back-btn {
      display: block;
      width: 200px;
      margin: 30px auto;
      padding: 12px 20px;
      background: #007bff;
      color: white;
      text-align: center;
      border-radius: 25px;
      text-decoration: none;
      font-weight: bold;
      transition: 0.3s ease-in-out;
    }

    .back-btn:hover {
      background: #0056b3;
      transform: scale(1.1);
    }
  </style>
</head>
<body>
  <header class="departments-header">
    <div class="container">
      <h1>Our Departments</h1>
      <p>Explore the wide range of medical specialties we offer to serve your health needs.</p>
    </div>
  </header>

  <section class="departments-section">
    <div class="container">
      <div class="department-grid">
        <?php
          $departments = [
            'cardiology ' => ['name' => 'Cardiology', 'image' => 'dep1.webp'],
            'pediatrics' => ['name' => 'Pediatrics', 'image' => 'dep2.jpg'],
            'orthopedics' => ['name' => 'Orthopedics', 'image' => 'dep3.jpg'],
            'neurology' => ['name' => 'Neurology', 'image' => 'dep4.jpg'],
            'dermatology' => ['name' => 'Dermatology', 'image' => 'dep5.jpg'],
            'gynecology' => ['name' => 'Gynecology', 'image' => 'dep6.jpg']
          ];
          
          foreach ($departments as $key => $data) {
            echo "<div class='department-card' id='{$key}-card'>
                    <img src='img/{$data['image']}' alt='{$data['name']}'>
                    <h3>{$data['name']}</h3>
                    <p>Expert services in {$data['name']}.</p>
                    <a href='patientportal.php?department={$key}' class='btn register-btn'>Register</a>
                  </div>";
          }
        ?>
      </div>
      <a href="index.php" class="btn back-btn">Back to Home</a>
    </div>
  </section>
</body>
</html>
