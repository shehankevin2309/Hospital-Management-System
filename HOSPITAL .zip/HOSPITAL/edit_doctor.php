<?php
// edit_doctor.php
include 'db.php';
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM Doctor WHERE doctor_id=$id");
    $doctor = $result->fetch_assoc();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST['doctor-name'];
        $specialty = $_POST['specialty'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $conn->query("UPDATE Doctor SET first_name='$name', specialty='$specialty', email='$email', phone='$phone' WHERE doctor_id=$id");
        echo "<script>alert('Doctor updated successfully!'); window.location.href='doctor.php';</script>";
    }
}
?>