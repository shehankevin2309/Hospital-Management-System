<?php
include 'db.php';

// Fetch patient details securely
$patient = null;
if (isset($_GET['id'])) {
    $patient_id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM Patient WHERE patient_id = ?");
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $patient = $result->fetch_assoc();
    $stmt->close();
}

// Handle case where patient does not exist
if (!$patient) {
    die("<script>alert('Error: Patient not found!'); window.location.href='patient.php';</script>");
}

// Handle form submission for updating patient details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['patient_id'];
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    $stmt = $conn->prepare("UPDATE Patient SET name=?, dob=?, gender=?, email=?, phone=?, address=? WHERE patient_id=?");
    $stmt->bind_param("ssssssi", $name, $dob, $gender, $email, $phone, $address, $id);
    
    if ($stmt->execute()) {
        echo "<script>alert('Patient details updated successfully!'); window.location.href='patient.php';</script>";
    } else {
        echo "<script>alert('Error updating patient details.');</script>";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('img/Background.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
            text-align: center;
            color: white;
        }
        .container {
            width: 50%;
            margin: auto;
            background: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 10px;
            margin-top: 50px;
            box-shadow: 0px 0px 15px rgba(255, 255, 255, 0.2);
        }
        h1 {
            color: #FFD700;
            text-shadow: 2px 2px 10px rgba(255, 255, 255, 0.5);
        }
        form {
            text-align: left;
        }
        label {
            font-weight: bold;
            color: #FFD700;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            border-radius: 5px;
            border: 1px solid #FFD700;
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }
        textarea {
            resize: none;
        }
        .btn {
            display: inline-block;
            width: 100%;
            padding: 12px;
            background-color: #FFD700;
            color: black;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            margin-top: 15px;
        }
        .btn:hover {
            background-color: #FFA500;
        }
        .back-btn {
            display: block;
            margin-top: 15px;
            color: #FFD700;
            text-decoration: none;
            font-size: 14px;
        }
        .back-btn:hover {
            color: #FFA500;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Edit Patient Details</h1>
        <form action="edit_patient.php" method="POST">
            <input type="hidden" name="patient_id" value="<?= htmlspecialchars($patient['patient_id']) ?>">
            <label>Name:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($patient['name']) ?>" required>
            <label>Date of Birth:</label>
            <input type="date" name="dob" value="<?= htmlspecialchars($patient['dob']) ?>" required>
            <label>Gender:</label>
            <select name="gender" required>
                <option value="Male" <?= ($patient['gender'] == 'Male') ? 'selected' : '' ?>>Male</option>
                <option value="Female" <?= ($patient['gender'] == 'Female') ? 'selected' : '' ?>>Female</option>
            </select>
            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($patient['email']) ?>" required>
            <label>Phone:</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($patient['phone']) ?>" required>
            <label>Address:</label>
            <textarea name="address" required><?= htmlspecialchars($patient['address']) ?></textarea>
            <button type="submit" class="btn">Update Patient</button>
        </form>
        <a href="patient.php" class="back-btn">⬅ Back to Patients</a>
    </div>

</body>
</html>
