<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Online Appointments</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      margin: 0;
      padding: 0;
    }

    .banner {
      background: url('img/online.jpg') no-repeat center center;
      background-size: cover;
      height: 250px;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: white;
      font-size: 26px;
      font-weight: bold;
      text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.5);
    }

    .container {
      width: 60%;
      margin: auto;
      background: white;
      padding: 20px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      margin-top: 20px;
    }

    h1, h2, h3 {
      text-align: center;
      color: #007bff;
    }

    p {
      text-align: center;
      font-size: 16px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px;
      border: 2px solid #007bff;
    }

    th {
      background-color: #007bff;
      color: white;
      text-align: left;
    }

    td input, td select, td textarea {
      width: 95%;
      padding: 8px;
      border: 1px solid #007bff;
      border-radius: 5px;
    }

    td textarea {
      resize: none;
    }

    .btn {
      display: block;
      width: 100%;
      padding: 12px;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      text-align: center;
      margin-top: 10px;
      transition: 0.3s ease-in-out;
    }

    .register-btn {
      background-color: #28a745;
    }

    .register-btn:hover {
      background-color: #218838;
      transform: scale(1.05);
    }

    .delete-btn {
      background-color: #dc3545;
    }

    .delete-btn:hover {
      background-color: #c82333;
      transform: scale(1.05);
    }

    .back-btn {
      display: block;
      text-align: center;
      margin-top: 10px;
      font-size: 16px;
      color: #007bff;
      text-decoration: none;
    }

    .back-btn:hover {
      text-decoration: underline;
    }

  </style>
</head>
<body>

  <div class="banner">
    <h1>Book Your Appointment Online</h1>
  </div>

  <div class="container">
    <h2>Schedule Your Appointment</h2>
    <p>We provide convenient and hassle-free online appointment booking for various specialties.</p>
    
    <h3>Our Specialties Include:</h3>
    <ul style="text-align: center;">
      <li>General Medicine</li>
      <li>Pediatrics</li>
      <li>Cardiology</li>
      <li>Dermatology</li>
    </ul>
    <p><strong>Need Assistance?</strong> Call us at <a href="tel:+94112345678">+94 11 234 5678</a></p>
    <a href="index.php" class="btn back-btn">Go Back to Home</a>
  </div>

  <!-- Online Appointment Registration Form -->
  <section class="registration-form">
    <div class="container">
      <h2>Appointment Booking Form</h2>
      <form action="submit_form.php" method="POST">
        <table>
          <tr>
            <th>Field</th>
            <th>Input</th>
          </tr>
          <tr>
            <td><label for="full-name">Full Name:</label></td>
            <td><input type="text" id="full-name" name="full-name" required></td>
          </tr>
          <tr>
            <td><label for="email">Email:</label></td>
            <td><input type="email" id="email" name="email" required></td>
          </tr>
          <tr>
            <td><label for="phone">Phone Number:</label></td>
            <td><input type="tel" id="phone" name="phone" required></td>
          </tr>
          <tr>
            <td><label for="specialty">Choose Specialty:</label></td>
            <td>
              <select id="specialty" name="specialty" required>
                <option value="">Select Specialty</option>
                <option value="general-medicine">General Medicine</option>
                <option value="pediatrics">Pediatrics</option>
                <option value="cardiology">Cardiology</option>
                <option value="dermatology">Dermatology</option>
              </select>
            </td>
          </tr>
          <tr>
            <td><label for="date">Preferred Date:</label></td>
            <td><input type="date" id="date" name="date" required></td>
          </tr>
          <tr>
            <td><label for="message">Additional Notes:</label></td>
            <td><textarea id="message" name="message" rows="4" placeholder="Any special requests or details..."></textarea></td>
          </tr>
        </table>

        <button type="submit" class="btn register-btn">Book Appointment</button>
        <button type="reset" class="btn delete-btn">Delete</button>
      </form>
    </div>
  </section>

</body>
</html>
