<?php
include 'db.php';

// CRUD operations for Medical Records
function createMedicalRecord($patient_id, $diagnosis, $treatment, $date) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO MedicalRecord (patient_id, diagnosis, treatment, record_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $patient_id, $diagnosis, $treatment, $date);
    $stmt->execute();
    $stmt->close();
}

function getMedicalRecords() {
    global $conn;
    $result = $conn->query("SELECT * FROM MedicalRecord");
    return $result->fetch_all(MYSQLI_ASSOC);
}

function updateMedicalRecord($id, $patient_id, $diagnosis, $treatment, $date) {
    global $conn;
    $stmt = $conn->prepare("UPDATE MedicalRecord SET patient_id=?, diagnosis=?, treatment=?, record_date=? WHERE record_id=?");
    $stmt->bind_param("isssi", $patient_id, $diagnosis, $treatment, $date, $id);
    $stmt->execute();
    $stmt->close();
}

function deleteMedicalRecord($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM MedicalRecord WHERE record_id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Medical Records</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f8fb;
      margin: 0;
      padding: 0;
    }
    .container {
      width: 60%;
      margin: auto;
      background: white;
      padding: 20px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      margin-top: 20px;
    }
    h1, h2 {
      text-align: center;
      color: #007BFF;
    }
    label {
      font-weight: bold;
      margin-top: 10px;
      display: block;
    }
    input, textarea {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #007BFF;
      border-radius: 5px;
    }
    table {
      width: 100%;
      margin-top: 10px;
      border-collapse: collapse;
    }
    th, td {
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #007BFF;
      color: white;
    }
    .btn {
      display: block;
      width: 100%;
      padding: 12px;
      background-color: #28a745;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      text-align: center;
      margin-top: 15px;
    }
    .btn:hover {
      background-color: #218838;
    }
    .back-btn {
      display: block;
      text-align: center;
      margin-top: 10px;
      font-size: 14px;
    }
  </style>
</head>
<body>

  <header class="medical-records-header">
    <div class="container">
      <h1>Medical Records</h1>
    </div>
  </header>

  <section class="medical-records-form">
    <div class="container">
      <a href="index.php" class="back-btn">⬅ Go Back to Home</a>
      <form action="submit_medical_records.php" method="POST">
        <table border="1">
          <tr>
            <th>Patient ID</th>
            <td><input type="text" id="patient-id" name="patient-id" required></td>
          </tr>
          <tr>
            <th>Diagnosis</th>
            <td><textarea id="diagnosis" name="diagnosis" rows="3" required></textarea></td>
          </tr>
          <tr>
            <th>Treatment</th>
            <td><textarea id="treatment" name="treatment" rows="3" required></textarea></td>
          </tr>
          <tr>
            <th>Prescriptions</th>
            <td><textarea id="prescriptions" name="prescriptions" rows="3" required></textarea></td>
          </tr>
        </table>
        <button type="submit" class="btn">Submit Medical Records</button>
      </form>
    </div>
  </section>

</body>
</html>
