<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Care Compass Hospitals</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: url('img/Background.jpg') no-repeat center center fixed;
      background-size: cover;
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      margin: 0;
      padding: 0;
    }
    .hero {
      background: url('img/hospital-hero.jpg') center/cover no-repeat;
      color: white;
      text-align: center;
      padding: 100px 20px;
      position: relative;
    }
    .hero-content {
      max-width: 700px;
      margin: auto;
      background: rgba(0, 0, 0, 0.6);
      padding: 20px;
      border-radius: 10px;
    }
    .btn {
      background-color: #007BFF;
      color: white;
      padding: 12px 20px;
      text-decoration: none;
      display: inline-block;
      border-radius: 5px;
      font-size: 18px;
      transition: 0.3s;
    }
    .btn:hover {
      background-color: #0056b3;
    }
    .services-row {
      display: flex;
      justify-content: space-between;
      gap: 20px;
      flex-wrap: wrap;
    }
    .service-card {
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      flex: 1;
      text-align: center;
    }
    .contact-form input, .contact-form textarea {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      border-radius: 5px;
      border: 1px solid #007BFF;
    }
    .navbar {
      background: #004080;;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 50px;
      color: black;
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1000;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    .navbar .logo {
      font-size: 24px;
      font-weight: bold;
      color:rgb(248, 252, 255);
    }
    .nav-links {
      list-style: none;
      display: flex;
      gap: 20px;
      margin: 0;
      padding: 0;
    }
    .nav-links li {
      display: inline;
      position: relative;
    }
    .nav-links a {
      color: black;
      text-decoration: none;
      font-size: 18px;
      padding: 8px 12px;
      display: block;
    }
    .nav-links a:hover {
      color:rgb(97, 132, 170);
    }
    .dropdown ul {
      display: none;
      position: absolute;
      background: white;
      list-style: none;
      padding: 10px;
      margin: 0;
      top: 100%;
      left: 0;
      min-width: 180px;
      border-radius: 5px;
      box-shadow: 0 4px 8px rgba(255, 255, 255, 0.88);
    }
    .dropdown:hover ul {
      display: block;
    }
    .dropdown ul li {
      width: 100%;
    }
    .dropdown ul li a {
      display: block;
      padding: 8px 12px;
      color: black;
    }
    .dropdown ul li a:hover {
      color: #007BFF;
    }
  </style>
</head>
<body>
  <header>
    <nav class="navbar">
        <div class="logo">Care Compass Hospitals</div>
        <ul class="nav-links">
            <li><a href="branch.php">Branches</a></li>
            <li><a href="patientportal.php">Patient Portal</a></li>
            <li><a href="department.php">Department</a></li>
            <!-- <li><a href="doctor.php">Doctor</a></li> -->
            <li class="dropdown">
                <a href="services.php">Services</a>
                <ul class="combobox">
                    <li><a href="labresults.php">Lab results</a></li>
                    <li><a href="online bill payment.php">Bill payment</a></li>
                </ul>
      </ul>
    </nav>
  </header>

  <section class="hero">
    <div class="hero-content">
      <h1>Making Health Care Better Together</h1>
      <p>
        Providing top-notch healthcare services for you and your family. Visit
        us to experience compassionate care and world-class treatment.
      </p>
      <a href="appointment.php" class="btn">Book an Appointment</a>
    </div>
  </section>

  <section class="our-services" id="services">
    <div class="container">
      <h2>Our Services</h2>
      <div class="services-row">
        <div class="service-card">
          <img src="img/service1.jpg" alt="Outpatient Services">
          <h3>Outpatient Services</h3>
          <p>Consultations, diagnostic tests, and minor procedures.</p>
        </div>
        <div class="service-card">
          <img src="img/service2.png" alt="Emergency Services">
          <h3>Emergency Services</h3>
          <p>24/7 emergency care for critical conditions.</p>
        </div>
        <div class="service-card">
          <img src="img/service3.webp" alt="Maternity Services">
          <h3>Maternity Services</h3>
          <p>Comprehensive care for expecting mothers.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="contact-us" id="contact">
    <div class="container">
      <h2>Contact Us</h2>
      <div class="contact-row">
        <div class="contact-info">
          <h3>Contact Information</h3>
          <p><strong>Phone:</strong> +94 123 456 789</p>
          <p><strong>Email:</strong> info@carecompass.lk</p>
          <p><strong>Address:</strong> 123 Main Street, Colombo, Sri Lanka</p>
        </div>
        <div class="contact-form">
          <h3>Send Us a Message</h3>
          <form action="#" method="post">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" placeholder="Your Message" rows="5" required></textarea>
            <button type="submit" class="btn">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </section>
</body>
</html>

