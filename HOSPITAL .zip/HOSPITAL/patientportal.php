<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php
    $department = isset($_GET['department']) && !empty($_GET['department']) ? ucfirst($_GET['department']) : 'Patient';
    echo "<title>{$department} Patient Registration</title>";
  ?>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f8fb;
      margin: 0;
      padding: 0;
    }
    .container {
      width: 60%;
      margin: auto;
      background: white;
      padding: 20px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      margin-top: 20px;
    }
    h2 {
      text-align: center;
      color: #007BFF;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 12px;
      border: 2px solid #007BFF;
    }
    th {
      background-color: #007BFF;
      color: white;
      text-align: left;
    }
    td input, td select, td textarea {
      width: 95%;
      padding: 8px;
      border: 1px solid #007BFF;
      border-radius: 5px;
    }
    td textarea {
      resize: none;
    }
    .btn, .home-btn {
      display: block;
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      text-align: center;
      margin-top: 15px;
      text-decoration: none;
    }
    .btn {
      background-color: #28a745;
      color: white;
    }
    .btn:hover {
      background-color: #218838;
    }
    .home-btn {
      background-color: #007BFF;
      color: white;
    }
    .home-btn:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>

  <header class="patient-registration-header">
    <div class="container">
      <h2><?php echo "{$department} Patient Registration"; ?></h2>
    </div>
  </header>

  <section class="registration-form">
    <div class="container">
      <form action="submit_patient_registration.php" method="POST">
        <input type="hidden" name="department" value="<?php echo $department; ?>">

        <table>
          <tr>
            <th>First Name</th>
            <td><input type="text" name="first_name" required></td>
          </tr>
          <tr>
            <th>Last Name</th>
            <td><input type="text" name="last_name" required></td>
          </tr>
          <tr>
            <th>Gender</th>
            <td>
              <select name="gender" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </td>
          </tr>
          <tr>
            <th>Date of Birth</th>
            <td><input type="date" name="dob" required></td>
          </tr>
          <tr>
            <th>Email</th>
            <td><input type="email" name="email" required></td>
          </tr>
          <tr>
            <th>Phone Number</th>
            <td><input type="tel" name="phone" required></td>
          </tr>
          <tr>
            <th>Address</th>
            <td><textarea name="address" rows="4" placeholder="Enter your address..."></textarea></td>
          </tr>
        </table>
        <button type="submit" class="btn">Register</button>
        <a href="index.php" class="home-btn">Back to Home</a>
      </form>
    </div>
  </section>

</body>
</html>
